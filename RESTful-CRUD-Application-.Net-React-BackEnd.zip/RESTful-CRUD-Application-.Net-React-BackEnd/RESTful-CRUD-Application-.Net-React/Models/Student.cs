﻿using System.ComponentModel.DataAnnotations;

namespace RESTful_CRUD_Application_.Net_React.Models
{
    public class Student
    {
        [Key]
        public int studentId { get; set; }

        public string studentName { get; set; }

        public string course { get; set; }
    }
}
