﻿using Microsoft.EntityFrameworkCore;

namespace RESTful_CRUD_Application_.Net_React.Models
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-U73V31J;Initial Catalog=student_management_system;Integrated Security=True; TrustServerCertificate=True;");
        }
    }
}
