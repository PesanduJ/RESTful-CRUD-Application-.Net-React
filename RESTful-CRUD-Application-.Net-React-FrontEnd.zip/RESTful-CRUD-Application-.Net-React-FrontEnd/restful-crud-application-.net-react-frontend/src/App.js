import StudentCrud from './components/StudentCrud';

function App() {
  return (
    <div>
      <StudentCrud/>
    </div>
  );
}

export default App;
