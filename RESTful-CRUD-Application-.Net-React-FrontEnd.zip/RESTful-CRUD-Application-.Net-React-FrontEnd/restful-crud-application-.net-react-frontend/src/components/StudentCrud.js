import axios from "axios"
import { useEffect, useState } from "react"

function StudentCrud() {
    const [studentId, setId] = useState("");
    const [studentName, setName] = useState("");
    const [course, setCourse] = useState("");
    const [students, setUsers] = useState([]);
    useEffect(() => {
        (async () => await Load())();
    }, []);
    async function Load() {

        const result = await axios.get("https://localhost:7216/api/Student/GetStudent");
        setUsers(result.data);
        console.log(result.data);
    }
    async function save(event) {

        event.preventDefault();
        try {
            await axios.post("https://localhost:7216/api/Student/AddStudent", {

            studentName: studentName,
                course: course,

            });
            alert("Student Registation Is Successfull");
            setId("");
            setName("");
            setCourse("");


            Load();
        } catch (err) {
            alert(err);
        }
    }

    async function editStudent(students) {
        setName(students.studentName);
        setCourse(students.course);

        setId(students.studentId);
    }

    async function DeleteStudent(studentId) {
        await axios.delete("https://localhost:7216/api/Student/DeleteStudent/" + studentId);
        alert("Student Deleted Successfully");
        setId("");
        setName("");
        setCourse("");
        Load();
    }

    async function update(event) {
        event.preventDefault();
        try {

            await axios.patch("https://localhost:7216/api/Student/UpdateStudent/" + students.find((u) => u.studentId === studentId).studentId || studentId,
                {
                    studentId: studentId,
                    studentName: studentName,
                    course: course,

                }
            );
            alert("Student Information Has Updated");
            setId("");
            setName("");
            setCourse("");

            Load();
        } catch (err) {
            alert(err);
        }
    }

    return (
        <div>
            <h1>Student Details</h1>
            <div class="container mt-4">
                <form>
                    <div class="form-group">

                        <input
                            type="text"
                            class="form-control"
                            id="studentId"
                            hidden
                            value={studentId}
                            onChange={(event) => {
                                setId(event.target.value);
                            }}
                        />

                        <label>Student Name</label>
                        <input
                            type="text"
                            class="form-control"
                            id="studentName"
                            value={studentName}
                            onChange={(event) => {
                                setName(event.target.value);
                            }}
                        />
                    </div>
                    <div class="form-group">
                        <label>Course</label>
                        <input
                            type="text"
                            class="form-control"
                            id="course"
                            value={course}
                            onChange={(event) => {
                                setCourse(event.target.value);
                            }}
                        />
                    </div>
                    <div>
                        <button class="btn btn-primary mt-4" onClick={save}>
                            Register
                        </button>
                        <button class="btn btn-warning mt-4" onClick={update}>
                            Update
                        </button>
                    </div>
                </form>
            </div>
            <br></br>

            <table class="table table-dark" align="center">
                <thead>
                    <tr>
                        <th scope="col">Student Id</th>
                        <th scope="col">Student Name</th>
                        <th scope="col">Course</th>

                        <th scope="col">Option</th>
                    </tr>
                </thead>
                {students.map(function fn(student) {
                    return (
                        <tbody>
                            <tr>
                                <th scope="row">{student.studentId} </th>
                                <td>{student.studentName}</td>
                                <td>{student.course}</td>

                                <td>
                                    <button
                                        type="button"
                                        class="btn btn-warning"
                                        onClick={() => editStudent(student)}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        type="button"
                                        class="btn btn-danger"
                                        onClick={() => DeleteStudent(student.studentId)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    );
                })}
            </table>

        </div>
    );
}

export default StudentCrud;
